# Clustering the uber clone app
- Run Command All Micro Services :- npx nodemon

## Gateway
    - npm init -y
    - npm i express express-http-proxy

## User
    - npm init -y
    - npm i express morgan mongoose bcrypt jsonwebtoken dotenv cookie-parser
    - npm i amqplib

## Captain
    - npm init -y
    - npm i express morgan mongoose bcrypt jsonwebtoken dotenv cookie-parser
    - npm i amqplib

## Ride
    - npm init -y
    - npm i express morgan mongoose bcrypt jsonwebtoken dotenv cookie-parser axios
    - npm i amqplib
